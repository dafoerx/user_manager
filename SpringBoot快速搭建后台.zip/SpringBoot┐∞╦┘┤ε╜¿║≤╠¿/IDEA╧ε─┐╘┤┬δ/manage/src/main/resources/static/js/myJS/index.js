// 监听添加按钮事件
$('#addUserBtn').click(function() {
	// 添加按钮被点击之后，展示modal框
	$('#modal-form-add').modal('show');
})
// 监听修改按钮事件
$('#updateUserBtn').click(function() {
	// 修改按钮被点击之后，展示modal框
	$('#modal-form-update').modal('show');
})